Thank you for buying our asset
URP Post Processing Profiles 1

Universal Render Pipeline Post Processing Profiles - pack of profiles for URP.
20 different settings for URP Post Processing.
Pack includes: Lomonew, Crazy,, Dark, Coziness, Coziness2, Autumn, Purple, Russian, Russian2, Vice2, Vice3, Movie1, Movie2, Movie3, Movie4, Horror, Horror2, Horror3, Dark, Dark2, Western
Coming Soon: Blood, Camera1, Camera_bw, Cry, Ice, Realistic, UE profiles and more.
Also you can use these profiles for Mobile. 
------

Please import Post processing-2 from Unity Package Manager for v2 and v3 profiles., after this - import Post Processing profiles.
(https://docs.unity3d.com/Packages/com.unity.package-manager-ui@1.8/manual/index.html)


How to use:
Version 3
Move prefab from v4 -> Prefabs to your scene.
If you want to use Global camera effect, just change Mode in Volume from “Local” to “Global”.
------
If you use it for mobile, just uncheck this parameter in profile:
Chromatic Abberation, Motion blur. For ultra low settings use only “Color Lookup” (LUTS)
------

https://www.gestgames.net/
Got any questions? Contact me now!
yrayushka@yahoo.com